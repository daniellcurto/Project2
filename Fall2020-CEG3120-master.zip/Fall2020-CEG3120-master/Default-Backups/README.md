# Backups

Contains backups of commonly overwritten config files.  Backups are from Ubuntu 18/20 system.
* `.profile`
* `.bashrc`